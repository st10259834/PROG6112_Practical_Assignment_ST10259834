package main;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.Test;

public class StudentTest {

    public StudentTest() {
    }

    public Student loadTestData() {
        // Initialize the student data
        Student.clearStudents(); // Clear existing data for isolation
        Student.SaveStudent(1, "John Doe", 18, "Computer Science", "john.doe@example.com");
        Student.SaveStudent(2, "Jane Smith", 17, "Engineering", "jane.smith@example.com");
        Student.SaveStudent(3, "Alice Johnson", 16, "Mathematics", "alice.johnson@example.com");
        return new Student();
    }

    @Test
    public void TestSaveStudent() {
        // Load test data
        var student = loadTestData();

        // Search for the student by ID and verify details
        String result = Student.SearchStudent(1);
        assertTrue(result.contains("John Doe"));
        assertTrue(result.contains("18"));
        assertTrue(result.contains("Computer Science"));
        assertTrue(result.contains("john.doe@example.com"));
    }

    @Test
    public void TestSearchStudent() {
        // Load test data
        var student = loadTestData();

        // Verify searching for a valid student ID returns the correct student details
        String result = Student.SearchStudent(2);
        assertTrue(result.contains("Jane Smith"));
        assertTrue(result.contains("17"));
        assertTrue(result.contains("Engineering"));
        assertTrue(result.contains("jane.smith@example.com"));
    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        // Load test data
        var student = loadTestData();

        // Verify searching for an invalid student ID returns an appropriate message
        String result = Student.SearchStudent(99);
        assertEquals("Student ID with ID 99 was not found!", result);
    }

    @Test
    public void TestDeleteStudent() {
        // Load test data
        var student = loadTestData();

        // Delete a student and verify the student has been removed
        String deleteMessage = Student.DeleteStudent(2);
        assertEquals("Student with ID 2 deleted successfully.", deleteMessage);

        // Verify the student is no longer searchable
        String result = Student.SearchStudent(2);
        assertEquals("Student ID with ID 2 was not found!", result);
    }

    @Test
    public void TestDeleteStudent_StudentNotFound() {
        // Load test data
        var student = loadTestData();

        // Attempt to delete a non-existent student and verify the appropriate message
        String deleteMessage = Student.DeleteStudent(99);
        assertEquals("Student ID with ID 99 was not found!", deleteMessage);
    }

    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Load test data
        var student = loadTestData();

        // Verify that a valid age (e.g., 18) is accepted
        int validAge = 18;
        assertTrue(validAge >= 16);
    }

    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        // Load test data
        var student = loadTestData();

        // Verify that an invalid age (e.g., 15) is rejected
        int invalidAge = 15;
        assertTrue(invalidAge < 16);
    }

    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        // Load test data
        var student = loadTestData();

        // Verify that an invalid character input for age throws a NumberFormatException
        String invalidAgeInput = "abc";
        try {
            int age = Integer.parseInt(invalidAgeInput);
            assertTrue(false, "Expected a NumberFormatException to be thrown");
        } catch (NumberFormatException e) {
            assertTrue(true);
        }
    }
}
