/*
 * Code Attribution:
 * - https://www.w3schools.com/java/default.asp
 * - https://stackoverflow.com/
 * - Author name: Bro Code, Channel: https://www.youtube.com/@BroCodez
 *   https://www.youtube.com/watch?v=NBIUbTddde4&list=PLZPZq0r_RZOMhCAyywfnYLlrjiVOkdAI1
 * - Author name: Alex Lee, Channel: https://www.youtube.com/@alexlorenlee
 *   https://www.youtube.com/watch?v=cCgOESMQe44
 * - Author name: Neso Academy, Channel: https://www.youtube.com/@nesoacademy
 *   https://www.youtube.com/watch?v=kWJHzambtNo&list=PLBlnK6fEyqRiraym3T703apTvEZLaSVtJ
 */



package main;

import java.util.Arrays;

public class Student {

    // class variables
    private static Integer[] studentIds;
    private static String[] studentNames;
    private static Integer[] studentAges;
    private static String[] studentCourses;
    private static String[] studentEmails;
    private static int currentIndex = 0;

    // Initialize the arrays with a fixed size
    static {
        int size = 100; // Define the size of the array
        studentIds = new Integer[size];
        studentNames = new String[size];
        studentAges = new Integer[size];
        studentCourses = new String[size];
        studentEmails = new String[size];
    }

    public static void SaveStudent(int studentId, String studentName, int studentAge, String studentCourse, String studentEmail) {
        if (currentIndex < studentIds.length) {
            studentIds[currentIndex] = studentId;
            studentNames[currentIndex] = studentName;
            studentAges[currentIndex] = studentAge;
            studentCourses[currentIndex] = studentCourse;
            studentEmails[currentIndex] = studentEmail;
            currentIndex++;
        } else {
            System.out.println("Cannot save student. Array is full.");
        }
    }

    public static String SearchStudent(int id) {
        for (int i = 0; i < currentIndex; i++) {
            if (studentIds[i].equals(id)) {
                return "STUDENT ID: " + studentIds[i] + "\n" +
                       "STUDENT NAME: " + studentNames[i] + "\n" +
                       "STUDENT AGE: " + studentAges[i] + "\n" +
                       "STUDENT EMAIL: " + studentEmails[i] + "\n" +
                       "STUDENT COURSE: " + studentCourses[i] + "\n";
            }
        }
        return "Student ID with ID " + id + " was not found!";
    }

    public static String DeleteStudent(int id) {
        for (int i = 0; i < currentIndex; i++) {
            if (studentIds[i].equals(id)) {
                // Shift elements to the left to fill the gap
                for (int j = i; j < currentIndex - 1; j++) {
                    studentIds[j] = studentIds[j + 1];
                    studentNames[j] = studentNames[j + 1];
                    studentAges[j] = studentAges[j + 1];
                    studentCourses[j] = studentCourses[j + 1];
                    studentEmails[j] = studentEmails[j + 1];
                }
                studentIds[currentIndex - 1] = null;
                studentNames[currentIndex - 1] = null;
                studentAges[currentIndex - 1] = null;
                studentCourses[currentIndex - 1] = null;
                studentEmails[currentIndex - 1] = null;
                currentIndex--;
                return "Student with ID " + id + " deleted successfully.";
            }
        }
        return "Student ID with ID " + id + " was not found!";
    }

    public static String StudentReport() {
        StringBuilder report = new StringBuilder("STUDENT REPORT\n");
        report.append("******************************\n");
        for (int i = 0; i < currentIndex; i++) {
            report.append("STUDENT ID: ").append(studentIds[i]).append("\n");
            report.append("STUDENT NAME: ").append(studentNames[i]).append("\n");
            report.append("STUDENT AGE: ").append(studentAges[i]).append("\n");
            report.append("STUDENT EMAIL: ").append(studentEmails[i]).append("\n");
            report.append("STUDENT COURSE: ").append(studentCourses[i]).append("\n");
            report.append("******************************\n");
        }
        return report.toString();
    }

    public static void validateAge(int age) {
        if (age < 16) {
            throw new IllegalArgumentException("Age must be 16 or greater.");
        }
    }

    // This method is used to clear the data for testing purposes
    public static void clearStudents() {
        Arrays.fill(studentIds, null);
        Arrays.fill(studentNames, null);
        Arrays.fill(studentAges, null);
        Arrays.fill(studentCourses, null);
        Arrays.fill(studentEmails, null);
        currentIndex = 0;
    }
}
