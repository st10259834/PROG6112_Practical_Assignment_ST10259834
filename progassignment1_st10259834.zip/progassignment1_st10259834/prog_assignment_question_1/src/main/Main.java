/*
 * Code Attribution:
 * - https://www.w3schools.com/java/default.asp
 * - https://stackoverflow.com/
 * - Author name: Bro Code, Channel: https://www.youtube.com/@BroCodez
 *   https://www.youtube.com/watch?v=NBIUbTddde4&list=PLZPZq0r_RZOMhCAyywfnYLlrjiVOkdAI1
 * - Author name: Alex Lee, Channel: https://www.youtube.com/@alexlorenlee
 *   https://www.youtube.com/watch?v=cCgOESMQe44
 * - Author name: Neso Academy, Channel: https://www.youtube.com/@nesoacademy
 *   https://www.youtube.com/watch?v=kWJHzambtNo&list=PLBlnK6fEyqRiraym3T703apTvEZLaSVtJ
 */


package main; 
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Initialize app variables
        boolean appLoop = true;
        boolean menuLoop;

        // Initialize the scanner outside the loop and close it at the end
        Scanner scanner = new Scanner(System.in);
        System.out.print("STUDENT MANAGEMENT APPLICATION\n");
        System.out.print("******************************\n");
        
        while (appLoop) {
           
            System.out.print("Enter (1) to launch menu or any key to exit\n\n");

            if (!scanner.nextLine().equals("1")) {
                appLoop = false;
            } else {
                menuLoop = true; // Reset the menu loop flag
                while (menuLoop) {
                    System.out.print("Please select one of the following menu items\n");
                    System.out.print("(1) Capture a new student\n");
                    System.out.print("(2) Search for a student\n");
                    System.out.print("(3) Delete a student\n");
                    System.out.print("(4) Print Student Report\n");
                    System.out.print("(5) Exit Application\n\n");

                    switch (scanner.nextLine()) {
                        case "1" -> {
                            // Capture inputs
                            System.out.print("CAPTURE A NEW STUDENT\n");
                            System.out.print("******************************\n");

                            System.out.print("Enter the student id: ");
                            int id = Integer.parseInt(scanner.nextLine());

                            System.out.print("Enter the student name: ");
                            String name = scanner.nextLine();

                            int age = 0;
                            boolean validAge = false;
                            do {
                                System.out.print("Enter the student age (must be 16 or greater): ");
                                String ageInput = scanner.nextLine();

                                try {
                                    age = Integer.parseInt(ageInput);
                                    if (age >= 16) {
                                        validAge = true; // Valid age entered
                                    } else {
                                        System.out.println("Age must be 16 or greater. Please re-enter the student age.");
                                    }
                                } catch (NumberFormatException e) {
                                    System.out.println("Invalid input. Please enter a numeric value for age.");
                                }
                            } while (!validAge);

                            System.out.print("Enter the student email: ");
                            String email = scanner.nextLine();

                            System.out.print("Enter the student course: ");
                            String course = scanner.nextLine();

                            // Save to array
                            Student.SaveStudent(id, name, age, course, email);
                            System.out.print("Saved Successfully! \n\n");
                        }

                        case "2" -> {
                            // Search for student by ID
                            System.out.print("Enter the student ID to search: \n");
                            String msg = Student.SearchStudent(Integer.parseInt(scanner.nextLine()));
                            
                            System.out.print("---------------------------------\n");
                            System.out.print(msg);
                            System.out.print("---------------------------------\n");
                        }

                        case "3" -> {
                            // Delete student by ID
                            System.out.print("Enter the student ID to delete: \n");
                            String msg = Student.DeleteStudent(Integer.parseInt(scanner.nextLine()));
                            
                            System.out.print("---------------------------------\n");
                            System.out.print(msg);
                            System.out.print("---------------------------------\n");
                        }

                        case "4" -> {
                            // Print Student Report
                            String report = Student.StudentReport();
                            
                            System.out.print("---------------------------------\n");
                            System.out.print(report);
                            System.out.print("---------------------------------\n");
                        }

                        case "5" -> {
                            // Exit the application
                            appLoop = false;
                            menuLoop = false;
                        }

                        default -> {
                            menuLoop = false;
                        }
                    }

                    // Exit menu
                    menuLoop = false;
                }
            }
        }

        // Close the scanner after the loop
        scanner.close();
    }
}
