package main;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.Test;

public class BookTest {

    public BookTest() {
    }

    public void loadTestData() {
        // Clear the book list before each test to ensure isolation
        Book.bookReport(); // Assuming bookReport initializes or clears the list
        // Add some test data
        FictionBook fictionBook = new FictionBook(1, "Fiction Title", "Author", 29.99, 100, "Fantasy");
        NonFictionBook nonFictionBook = new NonFictionBook(2, "Non-Fiction Title", "Author", 19.99, 50, "History");
        Book.saveBook(fictionBook);
        Book.saveBook(nonFictionBook);
    }

    @Test
    public void TestSaveBook() {
        // Load test data
        loadTestData();

        // Search for the book by ID and verify details
        String result = Book.searchBook(1);
        assertTrue(result.contains("Fiction Title"));
        assertTrue(result.contains("Author"));
        assertTrue(result.contains("29.99"));
        assertTrue(result.contains("Fantasy"));
    }

    @Test
    public void TestSearchBook() {
        // Load test data
        loadTestData();

        // Verify searching for a valid book ID returns the correct book details
        String result = Book.searchBook(2);
        assertTrue(result.contains("Non-Fiction Title"));
        assertTrue(result.contains("History"));
    }

    @Test
    public void TestSearchBook_BookNotFound() {
        // Load test data
        loadTestData();

        // Verify searching for an invalid book ID returns an appropriate message
        String result = Book.searchBook(99);
        assertEquals("Book with ID 99 was not found!", result);
    }

    @Test
    public void TestDeleteBook() {
        // Load test data
        loadTestData();

        // Delete a book and verify the book has been removed
        String deleteMessage = Book.deleteBook(2);
        assertEquals("Book with ID 2 deleted successfully.", deleteMessage);

        // Verify the book is no longer searchable
        String result = Book.searchBook(2);
        assertEquals("Book with ID 2 was not found!", result);
    }

    @Test
    public void TestDeleteBook_BookNotFound() {
        // Load test data
        loadTestData();

        // Attempt to delete a non-existent book and verify the appropriate message
        String deleteMessage = Book.deleteBook(99);
        assertEquals("Book with ID 99 was not found!", deleteMessage);
    }

    @Test
    public void TestBookReport() {
        // Load test data
        loadTestData();

        // Verify that the book report includes all saved books
        String report = Book.bookReport();
        assertTrue(report.contains("Fiction Title"));
        assertTrue(report.contains("Non-Fiction Title"));
    }
}