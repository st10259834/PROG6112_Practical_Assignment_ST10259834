/*
 * Code Attribution:
 * - https://www.w3schools.com/java/default.asp
 * - https://stackoverflow.com/
 * - Author name: Bro Code, Channel: https://www.youtube.com/@BroCodez
 *   https://www.youtube.com/watch?v=NBIUbTddde4&list=PLZPZq0r_RZOMhCAyywfnYLlrjiVOkdAI1
 *   https://www.youtube.com/watch?v=Zs342ePFvRI
 * - Author name: Alex Lee, Channel: https://www.youtube.com/@alexlorenlee
 *   https://www.youtube.com/watch?v=cCgOESMQe44
 *   https://www.youtube.com/watch?v=iV-rrFETXjY
 *   https://www.youtube.com/watch?v=zbVAU7lK25Q
 * - Author name: Neso Academy, Channel: https://www.youtube.com/@nesoacademy
 *   https://www.youtube.com/watch?v=kWJHzambtNo&list=PLBlnK6fEyqRiraym3T703apTvEZLaSVtJ
 */

package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Initialize app variables
        boolean appLoop = true;
        boolean menuLoop;

        // Initialize the scanner outside the loop and close it at the end
        Scanner scanner = new Scanner(System.in);
        System.out.print("BOOKSTORE MANAGEMENT APPLICATION\n");
        System.out.print("*********************************\n");
        
        while (appLoop) {
           
            System.out.print("Enter (1) to launch menu or any key to exit\n\n");

            if (!scanner.nextLine().equals("1")) {
                appLoop = false;
            } else {
                menuLoop = true; // Reset the menu loop flag
                while (menuLoop) {
                    System.out.print("Please select one of the following menu items\n");
                    System.out.print("(1) Add a new book\n");
                    System.out.print("(2) Search for a book\n");
                    System.out.print("(3) Delete a book\n");
                    System.out.print("(4) Print Book Report\n");
                    System.out.print("(5) Exit Application\n\n");

                    switch (scanner.nextLine()) {
                        case "1" -> {
                            // Capture inputs
                            System.out.print("ADD A NEW BOOK\n");
                            System.out.print("******************************\n");

                            System.out.print("Enter the book id: ");
                            int id = Integer.parseInt(scanner.nextLine());

                            System.out.print("Enter the book title: ");
                            String title = scanner.nextLine();

                            System.out.print("Enter the book author: ");
                            String author = scanner.nextLine();

                            System.out.print("Enter the book price: ");
                            double price = Double.parseDouble(scanner.nextLine());

                            System.out.print("Enter the number of copies sold: ");
                            int copiesSold = Integer.parseInt(scanner.nextLine());

                            System.out.print("Enter the book type (Fiction/Non-Fiction): ");
                            String type = scanner.nextLine();

                            if (type.equalsIgnoreCase("Fiction")) {
                                System.out.print("Enter the genre: ");
                                String genre = scanner.nextLine();
                                FictionBook fictionBook = new FictionBook(id, title, author, price, copiesSold, genre);
                                Book.saveBook(fictionBook);
                            } else if (type.equalsIgnoreCase("Non-Fiction")) {
                                System.out.print("Enter the subject: ");
                                String subject = scanner.nextLine();
                                NonFictionBook nonFictionBook = new NonFictionBook(id, title, author, price, copiesSold, subject);
                                Book.saveBook(nonFictionBook);
                            } else {
                                System.out.println("Invalid book type. Please enter either Fiction or Non-Fiction.");
                            }
                        }

                        case "2" -> {
                            // Search for book by ID
                            System.out.print("Enter the book ID to search: \n");
                            String msg = Book.searchBook(Integer.parseInt(scanner.nextLine()));
                            
                            System.out.print("---------------------------------\n");
                            System.out.print(msg);
                            System.out.print("---------------------------------\n");
                        }

                        case "3" -> {
                            // Delete book by ID
                            System.out.print("Enter the book ID to delete: \n");
                            String msg = Book.deleteBook(Integer.parseInt(scanner.nextLine()));
                            
                            System.out.print("---------------------------------\n");
                            System.out.print(msg);
                            System.out.print("---------------------------------\n");
                        }

                        case "4" -> {
                            // Print Book Report
                            String report = Book.bookReport();
                            
                            System.out.print("---------------------------------\n");
                            System.out.print(report);
                            System.out.print("---------------------------------\n");
                        }

                        case "5" -> {
                            // Exit the application
                            appLoop = false;
                            menuLoop = false;
                        }

                        default -> {
                            menuLoop = false;
                        }
                    }

                    // Exit menu
                    menuLoop = false;
                }
            }
        }

        // Close the scanner after the loop
        scanner.close();
    }
}