/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/*
 * Code Attribution:
 * - https://www.w3schools.com/java/default.asp
 * - https://stackoverflow.com/
 * - Author name: Bro Code, Channel: https://www.youtube.com/@BroCodez
 *   https://www.youtube.com/watch?v=NBIUbTddde4&list=PLZPZq0r_RZOMhCAyywfnYLlrjiVOkdAI1
 *   https://www.youtube.com/watch?v=Zs342ePFvRI
 * - Author name: Alex Lee, Channel: https://www.youtube.com/@alexlorenlee
 *   https://www.youtube.com/watch?v=cCgOESMQe44
 *   https://www.youtube.com/watch?v=iV-rrFETXjY
 *   https://www.youtube.com/watch?v=zbVAU7lK25Q
 * - Author name: Neso Academy, Channel: https://www.youtube.com/@nesoacademy
 *   https://www.youtube.com/watch?v=kWJHzambtNo&list=PLBlnK6fEyqRiraym3T703apTvEZLaSVtJ
 */




package main;

/**
 *
 * @author AaryanMakan
 */
public class BookBase {
    private int id;
    private String title;
    private String author;
    private double price;
    private int copiesSold;

    // Constructor
    public BookBase(int id, String title, String author, double price, int copiesSold) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.price = price;
        this.copiesSold = copiesSold;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

    public int getCopiesSold() {
        return copiesSold;
    }

    // Method to get a formatted string representing the book details
    public String getBookDetails() {
        return "BOOK ID: " + id + "\n" +
               "TITLE: " + title + "\n" +
               "AUTHOR: " + author + "\n" +
               "PRICE: $" + price + "\n" +
               "COPIES SOLD: " + copiesSold + "\n";
    }
}