/*
 * Code Attribution:
 * - https://www.w3schools.com/java/default.asp
 * - https://stackoverflow.com/
 * - Author name: Bro Code, Channel: https://www.youtube.com/@BroCodez
 *   https://www.youtube.com/watch?v=NBIUbTddde4&list=PLZPZq0r_RZOMhCAyywfnYLlrjiVOkdAI1
 *   https://www.youtube.com/watch?v=Zs342ePFvRI
 * - Author name: Alex Lee, Channel: https://www.youtube.com/@alexlorenlee
 *   https://www.youtube.com/watch?v=cCgOESMQe44
 *   https://www.youtube.com/watch?v=iV-rrFETXjY
 *   https://www.youtube.com/watch?v=zbVAU7lK25Q
 * - Author name: Neso Academy, Channel: https://www.youtube.com/@nesoacademy
 *   https://www.youtube.com/watch?v=kWJHzambtNo&list=PLBlnK6fEyqRiraym3T703apTvEZLaSVtJ
 */

package main;

import java.util.ArrayList;
import java.util.List;

public class Book {
    private static List<BookBase> books = new ArrayList<>();

    public static void saveBook(BookBase book) {
        books.add(book);
        System.out.println("Book saved successfully!");
    }

    public static String searchBook(int id) {
        for (BookBase book : books) {
            if (book.getId() == id) {
                return book.getBookDetails();
            }
        }
        return "Book with ID " + id + " was not found!";
    }

    public static String deleteBook(int id) {
        for (BookBase book : books) {
            if (book.getId() == id) {
                books.remove(book);
                return "Book with ID " + id + " deleted successfully.";
            }
        }
        return "Book with ID " + id + " was not found!";
    }

    public static String bookReport() {
        StringBuilder report = new StringBuilder("BOOK REPORT\n");
        report.append("******************************\n");
        for (BookBase book : books) {
            report.append(book.getBookDetails());
            report.append("******************************\n");
        }
        return report.toString();
    }
}