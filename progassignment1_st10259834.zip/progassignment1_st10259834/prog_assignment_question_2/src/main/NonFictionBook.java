/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/*
 * Code Attribution:
 * - https://www.w3schools.com/java/default.asp
 * - https://stackoverflow.com/
 * - Author name: Bro Code, Channel: https://www.youtube.com/@BroCodez
 *   https://www.youtube.com/watch?v=NBIUbTddde4&list=PLZPZq0r_RZOMhCAyywfnYLlrjiVOkdAI1
 *   https://www.youtube.com/watch?v=Zs342ePFvRI
 * - Author name: Alex Lee, Channel: https://www.youtube.com/@alexlorenlee
 *   https://www.youtube.com/watch?v=cCgOESMQe44
 *   https://www.youtube.com/watch?v=iV-rrFETXjY
 *   https://www.youtube.com/watch?v=zbVAU7lK25Q
 * - Author name: Neso Academy, Channel: https://www.youtube.com/@nesoacademy
 *   https://www.youtube.com/watch?v=kWJHzambtNo&list=PLBlnK6fEyqRiraym3T703apTvEZLaSVtJ
 */

package main;

/**
 *
 * @author AaryanMakan
 */
public class NonFictionBook extends BookBase {
    private String subject;

    // Constructor
    public NonFictionBook(int id, String title, String author, double price, int copiesSold, String subject) {
        super(id, title, author, price, copiesSold);
        this.subject = subject;
    }

    @Override
    public String getBookDetails() {
        return super.getBookDetails() + "SUBJECT: " + subject + "\n";
    }
}